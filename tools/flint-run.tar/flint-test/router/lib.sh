# Shared helpers for the router test scenarios (sourced by every scenario).
# A scenario snapshots /etc/xray first and puts it back at the end, also when it stops early.
# Output never contains subscription links, UUIDs or the PIN.
. /usr/share/flint/lib.sh
STATE=/tmp/flint-test-state.$$.tgz
LOCK=/tmp/flint-test.lock
PASS=0
FAIL=0

# One scenario at a time, and only with a good snapshot: restore_state replaces /etc/xray with it.
# The lock holds the pid of the scenario that took it: a lock left behind by a killed run (the wrapper
# was interrupted, the router was rebooted in the middle) is removed instead of blocking every scenario
# for good — that is exactly how a stale /tmp/flint-test.lock made whole runs report "skipped".
save_state() {
	if ! mkdir "$LOCK" 2>/dev/null; then
		old="$(cat "$LOCK/pid" 2>/dev/null)"
		if [ -n "$old" ] && [ "$old" != "$$" ] && kill -0 "$old" 2>/dev/null; then
			echo "  another test is running on the router ($LOCK, pid $old), scenario skipped"; exit 1
		fi
		echo "  removing a lock left by a killed run ($LOCK${old:+, pid $old})"
		rm -rf "$LOCK"
		mkdir "$LOCK" 2>/dev/null || { echo "  cannot take $LOCK, scenario skipped"; exit 1; }
	fi
	echo $$ > "$LOCK/pid"
	if ! { [ -s /etc/xray/flint.env ] && tar -C /etc -czf "$STATE" xray; }; then
		rm -rf "$LOCK"; echo "  cannot snapshot /etc/xray, scenario skipped"; exit 1
	fi
	keep_state
	trap restore_state EXIT
}
# keep_state: remember what runs now. Services outside /etc/xray (the Telegram proxy) are not in the
# snapshot, so a scenario that switches them off would otherwise leave the router in a state the user
# did not choose. Called by save_state.
keep_state() {
	TG_WAS_RUNNING=
	pidof tg-ws-proxy >/dev/null && TG_WAS_RUNNING=1
}
restore_state() {
	trap - EXIT
	if [ -s "$STATE" ]; then
		rm -rf /etc/xray && tar -C /etc -xzf "$STATE" && rm -f "$STATE"
	else
		# The snapshot is the only copy of the settings the router had: without it the scenario must say
		# so loudly, because the router may be left with the test's own servers and modes.
		echo "  !! snapshot $STATE is gone: /etc/xray left as the scenario made it (check the panel)"
	fi
	rmdir "$LOCK" 2>/dev/null
	flint-sub-update interval "$(cat /etc/xray/sub-interval 2>/dev/null || echo 24h)" >/dev/null
	flint-node apply >/dev/null 2>&1
	# The DoH config and the dnsmasq upstream are outside /etc/xray: bring them in line with the restored choice.
	flint-dns synced || flint-dns apply >/dev/null 2>&1
	flint-dns hosts apply
	flint-tg sync
	# flint-tg sync only restarts the proxy the settings ask for: put back the one that ran before the scenario.
	if [ -n "${TG_WAS_RUNNING:-}" ] && ! pidof tg-ws-proxy >/dev/null; then
		flint-tg on >/dev/null 2>&1
	fi
	# The firewall rule for the proxy is outside /etc/xray: drop it when the restored settings keep access closed.
	if [ "$(flint-tg remote)" != on ] && uci -q get firewall.flint_tg_remote >/dev/null; then flint-tg remote off >/dev/null 2>&1; fi
	echo "  restored; vpn: $(vpn_works && echo ok || echo FAIL)"
}
finish() {
	restore_state
	echo "  passed: $PASS, failed: $FAIL"
	[ "$FAIL" = 0 ]
}

# check <description> <command...>: the command's exit status decides.
check() {
	d="$1"; shift
	if "$@" >/dev/null 2>&1; then PASS=$((PASS + 1)); echo "  ok    $d"
	else FAIL=$((FAIL + 1)); echo "  FAIL  $d"; fi
}
fails() { ! "$@"; }

# Router state probes.
xray_running() { pidof xray >/dev/null; }
redirect_on() { iptables -t nat -S PREROUTING | grep -q -- '-j XRAY'; }
quic_blocked() { iptables -S FORWARD | grep -q 'dport 443 -j FLINT_QUIC'; }
sub_cron() { grep -q flint-sub-update /etc/crontabs/root; }
no_servers() { [ -z "$(flint-node codes)" ]; }
current_is() { [ "$(flint-node current)" = "$1" ]; }
vpn_works() {
	for i in 1 2 3; do
		[ -n "$(curl -s -m 15 -x http://127.0.0.1:1087 https://ifconfig.me)" ] && return 0
		sleep 2
	done
	return 1
}
direct_works() { [ -n "$(curl -s -m 8 https://ifconfig.me)" ]; }
# panel_has <tab> <text>: the Russian panel page contains the text.
# Pages are read with grep -c, not -q: busybox wget hangs for about a minute when the reader quits early.
panel_has() {
	pin="$(sed -n 's/^UI_PIN=//p' /etc/xray/flint.env | tr -d '"')"
	wget -qO- "http://127.0.0.1:81/cgi-bin/panel.cgi?pass=$pin&lang=ru&tab=$1" | grep -c "$2"
}
# The no-servers state: devices online directly, nothing for Xray to run.
direct_mode() {
	check "no servers" no_servers
	check "xray stopped" fails xray_running
	check "no redirect into xray" fails redirect_on
	check "QUIC not blocked" fails quic_blocked
	check "internet works directly" direct_works
}
vpn_mode() {
	check "xray running" xray_running
	check "LAN redirected into xray" redirect_on
	check "QUIC blocked" quic_blocked
	check "vpn works" vpn_works
}

# Server lines and the first subscription link before a scenario empties the router.
first_node_line() { node_lines $(node_files) | head -n1; }
first_sub_url() { head -n1 /etc/xray/subscriptions 2>/dev/null | cut -f2; }
# Remove every server and subscription; an empty subscriptions file keeps SUB_URL from seeding it again.
go_empty() {
	rm -rf /etc/xray/nodes.conf /etc/xray/nodes.d /etc/xray/nodes-custom.conf /etc/xray/sub-status /etc/xray/current-node
	: > /etc/xray/subscriptions
	flint-node apply >/dev/null 2>&1
}
